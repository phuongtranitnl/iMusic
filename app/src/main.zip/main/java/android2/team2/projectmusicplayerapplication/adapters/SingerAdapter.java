package android2.team2.projectmusicplayerapplication.adapters;

import android.content.Context;
import android.media.MediaPlayer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import android2.team2.projectmusicplayerapplication.R;
import android2.team2.projectmusicplayerapplication.models.Singer;

public class SingerAdapter extends RecyclerView.Adapter<SingerAdapter.SingerViewHolder> {

    List<Singer> listSingerAdapter;
    Context context;
    private SongAdapter.OnItemClickListener onItemClickListener;
    private MediaPlayer mediaPlayer;
    static int position = -1;

    public SingerAdapter(List<Singer> listSingerAdapter, Context context) {
        this.listSingerAdapter = listSingerAdapter;
        this.context = context;
    }

    public  interface OnItemClickListener {
        void onItemClick(View view, Singer singer, int i);
    }

    @NonNull
    @Override
    public SingerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.item_song, viewGroup, false);
        final SingerAdapter.SingerViewHolder singerViewHolder = new SingerAdapter.SingerViewHolder(view);
        singerViewHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mediaPlayer && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                    position = -1;
                }
                if (songViewHolder.getAdapterPosition() != position) {
                    mediaPlayer = MediaPlayer.create(context, songArrayList.get(songViewHolder.getAdapterPosition()).getSongFile());
                    position = songViewHolder.getAdapterPosition();
                    mediaPlayer.start();
                }
            }
        });
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull SingerViewHolder singerViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    public class SingerViewHolder {
        public SingerViewHolder(View view) {
        }
    }
}
